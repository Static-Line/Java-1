/*******************
Name:Brendan McCullagh

Date:20210215

Notes:none
*******************/

public class PassValue
{
   public static void main(String[] args)
   {
      String message = "Hello my name is Tacos"; 
      sub(message); 
   }
   public static void sub(String myMessage)
   {
      System.out.println(myMessage); 
   }
}