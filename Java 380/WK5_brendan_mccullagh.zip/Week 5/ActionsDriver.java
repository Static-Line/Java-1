/*******************
Name:Brendan McCullagh

Date:20210305

Notes:
*******************/


// Program to test out the Actions class
class ActionsDriver
{

   public static void main (String[] args)
   {
   
      Actions eg = new Actions(); // Initialize the program GUI
   }
}